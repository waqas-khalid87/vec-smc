# VEC (SMC-Pvt) Ltd Website
Deployed on GitHub Pages